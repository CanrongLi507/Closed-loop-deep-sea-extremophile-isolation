import numpy as np
import cv2


class VisualCalibration:
    """
    Section 3.4.1 Optical Calibration and Preprocessing
    Function: Processing camera parameters, flat field correction, and disparity compensation.
    """

    def __init__(self):
        self.K = np.eye(3)  # Intrinsic matrix
        self.dist_coeffs = np.zeros(5)  # Distortion coefficient [k1, k2, p1, p2, k3]
        self.parallax_vec = np.zeros(2)  # Disparity vector k
        self.flat_field_mean = 1.0

    def set_intrinsics(self, fx, fy, cx, cy, distortion):
        """
        Simulate Zhang's method calibration results
        """
        self.K = np.array([[fx, 0, cx],
                           [0, fy, cy],
                           [0, 0, 1]])
        self.dist_coeffs = np.array(distortion)

    def calibrate_parallax(self, p_base, p_high, z_base, z_high):
        """
        Calculate differential disparity vector k_vec
        k_vec = (P_high - P_base) / (Z_high - Z_base)
        """
        delta_p = np.array(p_high) - np.array(p_base)
        delta_z = z_high - z_base

        if abs(delta_z) > 1e-6:
            self.parallax_vec = delta_p / delta_z  # Eq. 22
        else:
            self.parallax_vec = np.zeros(2)

        print(f"Parallax Vector calibrated: {self.parallax_vec} pixel/mm")

    def correct_image(self, img_raw, img_dark, img_flat):
        """
        Flat-field correction
        I_corr = (I_undist - I_dark) / (I_flat - I_dark) * Mean(I_flat)
        """
        # 1. Global undistortion
        img_undist = cv2.undistort(img_raw, self.K, self.dist_coeffs)

        # 2. Flat field correction formula Eq. 23
        numerator = img_undist.astype(float) - img_dark.astype(float)
        denominator = img_flat.astype(float) - img_dark.astype(float)

        # Avoid zero elimination
        denominator[denominator < 1e-6] = 1e-6

        mean_flat = np.mean(img_flat)
        img_corr = (numerator / denominator) * mean_flat

        # Truncate to 0-255 and return to uint8
        return np.clip(img_corr, 0, 255).astype(np.uint8)


class InstanceSegmentationParser:
    """
    Section 3.4.2 Deep Learning-Based Instance Segmentation
    Function: Simulate YOLOv11 seg Head output processing, i.e. mask generation formula.
    """

    def __init__(self, num_prototypes=32):
        self.num_prototypes = num_prototypes

    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    def generate_mask(self, mask_coeffs, prototypes):
        """
        Core mask generation logic Eq. 24
        M_i = sigma(C_i x P)
        """
        # mask_coeffs: (1, 32) - Instance specific mask coefficients C_i
        # prototypes: (32, 160, 160) - Prototype mask tensor P

        # Matrix multiplication simulates tensor operations (C_i * P)
        # Reshape prototypes to (32, H*W) for dot product
        h, w = prototypes.shape[1], prototypes.shape[2]
        proto_flat = prototypes.reshape(self.num_prototypes, -1)

        # Linear combination
        linear_comb = np.dot(mask_coeffs, proto_flat)

        # Sigmoid
        mask_prob = self.sigmoid(linear_comb)

        # Reshape
        mask_final = mask_prob.reshape(h, w)

        # Binary conversion (Threshold> 0.5) yields prospects
        binary_mask = (mask_final > 0.5).astype(int)

        return binary_mask

    def post_process(self, binary_mask):
        """
        Post processing: Extract coordinate set S
        """
        # Get all foreground pixel coordinates Eq. 26
        # np.where return (row_indices, col_indices) -> (y, x)
        ys, xs = np.where(binary_mask == 1)
        coordinates = list(zip(xs, ys))  # (x, y)
        return coordinates


class ColonyClassifier:
    """
    Section 3.4.3 Multi-Dimensional Fingerprinting and Decision Logic
    Function: Feature based selection decision.
    """

    def __init__(self):
        # Threshold definition
        self.rf_thresh = 0.80
        self.xgb_thresh = 0.85
        self.circ_thresh = 0.85
        self.solid_thresh = 0.90
        self.area_min = 0.2
        self.area_max = 12.0

    def extract_features(self, mask, img):
        """
        Simulated feature extraction (geometry, color, luminosity)
        In practical applications, convex hull and HSV mean will be calculated. Here returns the simulated value.
        """
        features = {
            "circularity": 0.88,  # Simulated value
            "solidity": 0.95,  # Simulated value
            "area": 5.0,  # mm^2
            "color_h": 30,
            "photometric_energy": 120
        }
        return features

    def decide_pickability(self, features, score_xgb, score_rf):
        """
        Dual core mutual supervision decision logic Eq. 27 and geometric gating
        """
        # 1. Geometric Gating
        if features['circularity'] <= self.circ_thresh:
            return False, "Bad Circularity"
        if features['solidity'] <= self.solid_thresh:
            return False, "Bad Solidity"
        if not (self.area_min < features['area'] < self.area_max):
            return False, "Area Out of Bounds"

        # 2. Dual-core Consensus
        is_consensus = (score_xgb > self.xgb_thresh) and (score_rf > self.rf_thresh)

        if is_consensus:
            return True, "Pickable"
        else:
            return False, "Low Confidence"


class CompliancePicker:
    """
    Section 3.4.4 Decoupled Pose Estimation and PID-Driven Compliance
    Function: Lateral positioning and vertical PID force control.
    """

    def __init__(self, kp=1.0, ki=0.1, kd=0.05, dt=0.01):
        self.M_persp = np.eye(3)  # Perspective transformation matrix T

        # PID
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.dt = dt

        self.integral_error = 0.0
        self.prev_error = 0.0

        # Target power setting (assuming Agar 1.5%)
        self.f_set = 0.12  # Mean of [0.10, 0.15]
        self.f_thresh = 0.02  # Contact detection threshold

    def set_transform_matrix(self, matrix):
        self.M_persp = np.array(matrix)

    def map_lateral_position(self, u, v):
        """
        The mapping Eq. 28 from pixel coordinates (u, v) to robot base coordinates (xb, yb)
        [xb, yb, 1]^T = T * [u, v, 1]^T
        """
        uv_vec = np.array([u, v, 1.0])
        base_vec = np.dot(self.M_persp, uv_vec)

        # Normalization (Eq.28, perspective transformation usually requires division by the z-component)
        if abs(base_vec[2]) > 1e-6:
            xb = base_vec[0] / base_vec[2]
            yb = base_vec[1] / base_vec[2]
        else:
            xb, yb = base_vec[0], base_vec[1]

        return xb, yb

    def update_vertical_control(self, f_meas):
        """
        PID driven vertical velocity control Eq. 29
        v_z(t) = Kp*e + Ki*int(e) + Kd*de/dt
        """
        # Error Definition: Target Force - Measured Force
        # Note: We require downward motion to increase the applied force.
        # If F_meas < F_set (insufficient force), Error > 0.
        # Consequently, v_z should be > 0 (assuming downward velocity is positive) to increase contact depth.
        # Important: This direction logic is the inverse of the Admittance Control in Part 2 
        # (which used position correction, whereas this uses a direct velocity command).
        # The reference text explicitly defines v_z(t) as the velocity command.

        error = self.f_set - f_meas  # e(t)

        # Integral term
        self.integral_error += error * self.dt

        # Differential term
        derivative = (error - self.prev_error) / self.dt
        self.prev_error = error

        # PID calculation
        v_z_cmd = (self.kp * error) + (self.ki * self.integral_error) + (self.kd * derivative)

        # Contact Detection Logic
        # Before contact (F_meas < F_thresh), the system operates in "free-space mode".
        # Note: The reference text describes this as "medium-velocity free-space mode".
        # Simulation strategy: If the measured force is negligible, apply a constant downward velocity to approach the surface.
        if f_meas < self.f_thresh:
            # Free space approach velocity (simulated value)
            return 5.0  # mm/s
        else:
            # Closed loop PID after contact
            return v_z_cmd

    def verify_pick_success(self, img_before, img_after, threshold=5000):
        """
        Closed loop verification Eq. 30
        Sum(|I_after - I_before|) < Threshold_empty
        """
        diff = np.abs(img_before.astype(float) - img_after.astype(float))
        total_diff = np.sum(diff)

        # Logic Verification:
        # If the picking process is successful, the colony is removed, resulting in a significant image difference
        # (effectively replacing the colony with the background).

        # Interpretation of Eq. 30:
        # The equation states: `diff < Threshold_empty` -> Failure.
        # The term "Threshold_empty" implies a check for whether the location is effectively "empty" (background only).
        # Context: `I_before` contains the colony; `I_after` should show the empty background.
        # Therefore, the difference `Sum(|I_after - I_before|)` is expected to be large upon success.
        # Conclusion: If the difference is small (below the threshold), it implies the colony is still present (not removed), signifying a failure.

        if total_diff < threshold:
            return False, total_diff  # Failure
        else:
            return True, total_diff  # Success


# ==========================================
# Simulation
# ==========================================
if __name__ == "__main__":
    # Initialization
    calib = VisualCalibration()
    parser = InstanceSegmentationParser()
    classifier = ColonyClassifier()
    picker = CompliancePicker(kp=2.0, ki=0.5, kd=0.1)

    # 1. Simulate visual calibration
    # Assuming simple pixel to millimeter scaling
    print("--- 1. Calibration ---")
    calib.calibrate_parallax(p_base=(100, 100), p_high=(105, 105), z_base=0, z_high=5)

    # Set the simulated perspective transformation matrix (Unit scaling for demo)
    picker.set_transform_matrix([[0.1, 0, -10], [0, 0.1, -10], [0, 0, 1]])

    # 2. Simulate YOLO Mask generation
    print("\n--- 2. Segmentation ---")
    # Simulate Coefficients (1x32) and Prototypes (32x10x10 small for demo)
    coeffs = np.random.randn(1, 32)
    protos = np.random.randn(32, 10, 10)

    mask = parser.generate_mask(coeffs, protos)
    coords = parser.post_process(mask)
    # Assuming a colony center is detected at (5,5)
    u_target, v_target = 5, 5
    print(f"Generated Mask shape: {mask.shape}, Target Pixel: ({u_target}, {v_target})")

    # 3. Simulate classification decision-making
    print("\n--- 3. Classification ---")
    # Simulation model scoring
    score_xgb = 0.92
    score_rf = 0.88
    feats = classifier.extract_features(mask, None)
    pickable, reason = classifier.decide_pickability(feats, score_xgb, score_rf)
    print(f"Features: {feats}")
    print(f"Decision: {reason} (XGB: {score_xgb}, RF: {score_rf})")

    if pickable:
        # 4. Simulate picking control loop
        print("\n--- 4. Picking Control Loop ---")

        # Mapping coordinates
        xb, yb = picker.map_lateral_position(u_target, v_target)
        print(f"Mapped Base Coordinates: x={xb:.2f}, y={yb:.2f}")

        print(f"{'Time':<6} | {'F_meas':<8} | {'Error':<8} | {'V_z_cmd':<8} | {'State'}")
        print("-" * 55)

        # Simulate PID process
        # The initial force is 0, gradually coming into contact and stabilizing until reaching F_set (0.12 N)
        sim_forces = [0.0, 0.0, 0.015, 0.04, 0.08, 0.11, 0.125, 0.12, 0.12]

        for i, f_val in enumerate(sim_forces):
            t = i * picker.dt
            v_cmd = picker.update_vertical_control(f_val)

            # Status judgment
            state = "Approach" if f_val < picker.f_thresh else "PID Control"
            err = picker.f_set - f_val

            print(f"{t:<6.2f} | {f_val:<8.3f} | {err:<8.3f} | {v_cmd:<8.3f} | {state}")

        # 5. Simulate closed-loop verification
        print("\n--- 5. Post-Pick Verification ---")
        # Simulate two images with significant differences (successful)
        img_pre = np.ones((10, 10)) * 200  # Bright spot
        img_post = np.zeros((10, 10))  # Dark background
        success, diff_val = picker.verify_pick_success(img_pre, img_post, threshold=500)
        print(f"Image Difference: {diff_val:.1f} -> Pick Success: {success}")