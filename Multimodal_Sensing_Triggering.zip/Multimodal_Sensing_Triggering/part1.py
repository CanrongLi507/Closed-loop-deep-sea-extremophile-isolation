import numpy as np
from collections import deque
from scipy.signal import savgol_filter, correlate


class AdaptiveKalmanFilter:
    """
    Section 3.1.1 Data Preprocessing 
    The measurement noise was adaptively modulated based on statistical properties derived from a sliding window, which in turn dynamically updated the Kalman gain.
    """

    def __init__(self, process_noise=1e-5, measure_noise_base=1e-2, window_size=50):
        self.Q = process_noise  # Process Noise Covariance
        self.R_base = measure_noise_base  # Covariance of Basic Observation Noise
        self.window_size = window_size
        self.buffer = deque(maxlen=window_size)

        # Initial State
        self.x = 0.0  # State Estimate
        self.P = 1.0  # Error Covariance
        self.K = 0.0  # Kalman Gain

        # Innovation Ratio
        self.innovation = 0.0
        self.trace_P = 0.0

    def update(self, z_measurement):
        """
        Perform one filtering iteration
        Formula: z_k = z_{k|k-1} + K_k * (z_k - H * z_{k|k-1}) 
        """
        self.buffer.append(z_measurement)

        # 1. Prediction
        x_pred = self.x
        P_pred = self.P + self.Q

        # 2. Adaptive R based on sliding window statistics
        if len(self.buffer) > 10:
            window_std = np.std(self.buffer)
            # If the variance within the window is high, treat it as high-frequency noise.
            # Increase measurement noise (R) to reduce the Kalman Gain (K),
            # thereby prioritizing the model prediction and suppressing noise.
            R_adaptive = self.R_base * (1 + window_std * 10)
        else:
            R_adaptive = self.R_base

        # 3. Update
        # H = 1 (Measurement matrix is assumed to be identity (direct state observation))
        S = P_pred + R_adaptive  # Innovation Covariance
        self.K = P_pred / S  # Kalman Gain K_k

        self.innovation = z_measurement - x_pred  # Measurement Residual (z_k - H*x)
        self.x = x_pred + self.K * self.innovation  # Status Update
        self.P = (1 - self.K) * P_pred  # Covariance Update

        self.trace_P = self.P  # In the 1D case, Trace(P) is simply P itself.

        return self.x


class DynamicCompensator:
    """
    Section 3.1.3 Dynamic time-delay compensation mechanism 
    Function: Compute sensor lag and reconstruct signal via Taylor expansion deconvolution.
    """

    def __init__(self, window_size=100, max_lag=20, sg_window=11, sg_poly=2):
        self.window_size = window_size
        self.max_lag = max_lag
        self.sg_window = sg_window  # Savitzky-Golay
        self.sg_poly = sg_poly

        # Stores the fast response signal (ref) and the slow response signal (target)
        self.ref_buffer = deque(maxlen=window_size)
        self.target_buffer = deque(maxlen=window_size)

    def process(self, s_ref_val, s_target_val):
        """
        Takes real-time data input and returns the reconstructed physical state X_j(t)
        """
        self.ref_buffer.append(s_ref_val)
        self.target_buffer.append(s_target_val)

        if len(self.ref_buffer) < self.window_size:
            return s_target_val  # Insufficient data -> Return raw value

        # 1. Real-time Lag Estimation
        # Formula (4): argmax Integral(S_ref * S_i(xi + delta))
        ref_arr = np.array(self.ref_buffer)
        target_arr = np.array(self.target_buffer)

        # Calculate lag using cross-correlation
        correlation = correlate(ref_arr - np.mean(ref_arr), target_arr - np.mean(target_arr), mode='full')
        lags = np.arange(-len(ref_arr) + 1, len(ref_arr))

        # Find the maximum correlation within the range of [0, delta_max]
        valid_mask = (lags >= 0) & (lags <= self.max_lag)
        if np.any(valid_mask):
            valid_lags = lags[valid_mask]
            valid_corr = correlation[valid_mask]
            tau_idx = np.argmax(valid_corr)
            tau_t = valid_lags[tau_idx]  # The total lag calculated at the current moment tau_i(t)
        else:
            tau_t = 0

        # 2. Hybrid Deconvolutional Reconstruction
        # Formula (5): X_j(t) approx S_j(t) + tau_j(t) * d/dt(S_j(t))

        # Calculate the derivative d/dt (S2j) and use Savitzky Golay filter to suppress noise
        # Fit and differentiate the most recent data
        if len(self.target_buffer) >= self.sg_window:
            recent_target = list(self.target_buffer)[-self.sg_window:]
            derivs = savgol_filter(recent_target, window_length=self.sg_window, polyorder=self.sg_poly, deriv=1)
            ds_dt = derivs[-1]  # Derivative at the current moment
        else:
            ds_dt = 0.0

        X_j_t = s_target_val + tau_t * ds_dt  #

        return X_j_t


class FeatureFusion:
    """
    Section 3.1.2 Feature Fusion
    Function: Construct feature vectors and calculate environmental abundance scores
    X(t) = [Ĉ_CH4(t), Ĉ_CO2(t), ..., ∇σ(t)]^T
    Score(t) = W^T X(t)
    """

    def __init__(self, num_features=7):
        # Initialize weight vector, adjustable according to microbial metabolic preferences
        self.W = np.ones(num_features) / num_features  # Initialize as uniform weight
        self.num_features = num_features

    def construct_feature_vector(self, ch4_val, co2_val, chla_val, temp_val, pres_val, do_val, cond_grad):
        """
        Construct feature vectors X(t) = [Ĉ_CH4(t), Ĉ_CO2(t), ĈCHL-a(t), ĈT(t), ĈP(t), ĈDO(t), ∇σ(t)]^T
        """
        X = np.array([ch4_val, co2_val, chla_val, temp_val, pres_val, do_val, cond_grad])
        return X

    def calculate_score(self, feature_vector):
        """
        Calculate environmental abundance score Score(t) = W^T X(t)
        """
        score = np.dot(self.W, feature_vector)
        return score

    def update_weights(self, new_weights):
        """
        Updating weight vectors through Bayesian learning
        """
        if len(new_weights) == self.num_features:
            self.W = np.array(new_weights)
        else:
            raise ValueError(f"Weights length must be {self.num_features}")


class RegimeAwareTrigger:
    """
    Section 3.2 Regime-Aware Probabilistic Sampling Trigger
    Function: Combining background estimation, gradient locking, and probability fusion for sampling decision-making.
    """

    def __init__(self, mad_window=200, freeze_cycles=10):
        self.buffer = deque(maxlen=mad_window)
        self.mad_window = mad_window

        # Threshold freezing logic
        self.freeze_cycles = freeze_cycles
        self.monotonic_counter = 0
        self.frozen_threshold = None

        # Gradient locking logic
        self.prev_x = 0.0
        self.slope_threshold = 0.05  # epsilon_slope

        # weight parameter
        self.w_E = 0.4  # Energy weight
        self.w_S = 0.3  # Stability weight
        self.w_R = 0.3  # Reliability weight

        # Add feature fusion component
        self.feature_fusion = FeatureFusion()

    def calculate_background_threshold(self, current_val):
        """
        Calculate adaptive background threshold based on MAD T_dyn
        """
        self.buffer.append(current_val)
        if len(self.buffer) < 10:
            return float('inf')

        # Check monotonic trends to prevent threshold inflation
        if current_val > self.prev_x:
            self.monotonic_counter += 1
        else:
            self.monotonic_counter = 0
            self.frozen_threshold = None  # Reset Freeze

        if self.monotonic_counter >= self.freeze_cycles and self.frozen_threshold is None:
            # Calculate and freeze threshold
            data = np.array(self.buffer)
            med = np.median(data)
            mad = np.median(np.abs(data - med))
            kappa = 1.4826  #
            self.frozen_threshold = med + 3.0 * kappa * mad  # lambda set 3.0

        if self.frozen_threshold is not None:
            return self.frozen_threshold

        # Normal calculation of dynamic threshold
        data = np.array(self.buffer)
        med = np.median(data)
        mad = np.median(np.abs(data - med))
        kappa = 1.4826
        return med + 3.0 * kappa * mad  # formula (7)

    def decide_with_features(self, ch4_val, co2_val, chla_val, temp_val, pres_val, do_val, cond_grad, kf_instances):
        """
        Decision logic using feature fusion
        """
        # Construct feature vectors
        X_t = self.feature_fusion.construct_feature_vector(ch4_val, co2_val, chla_val, temp_val, pres_val, do_val, cond_grad)

        # Calculate environmental abundance score
        score = self.feature_fusion.calculate_score(X_t)

        # Calculate threshold using traditional methods
        threshold = self.calculate_background_threshold(score)

        # Gradient locking logic
        dx_dt = score - self.prev_x
        self.prev_x = score

        # Check if the triggering conditions are met
        if score < threshold or abs(dx_dt) > self.slope_threshold:
            return False, score

        # Using one of the Kalman filter instances to obtain innovation rate information
        if kf_instances:
            kf_instance = kf_instances[0]  # Use the first available KF instance
            # Calculate innovation rate eta_k
            if kf_instance.trace_P > 1e-9:
                eta_k = (kf_instance.innovation ** 2) / kf_instance.trace_P
            else:
                eta_k = 0

            # Dynamically adjust reliability weights
            current_w_R = self.w_R
            if eta_k > 5.0:  # Significance threshold
                current_w_R *= 0.1

            # Calculate the final score
            u_energy = min((score - threshold) / max(threshold, 0.001), 1.0)
            u_stability = max(1.0 - abs(dx_dt) / self.slope_threshold, 0.0)
            u_reliability = max(1.0 - kf_instance.trace_P, 0.0)

            final_score = self.w_E * u_energy + self.w_S * u_stability + current_w_R * u_reliability
        else:
            final_score = score

        # Final trigger judgment
        trigger = final_score > 0.6
        return trigger, final_score

    def decide(self, x_t, kf_instance):
        """
        Core Decision Logic
        x_t: Reconstructed State
        kf_instance: The currently used Kalman filter instance (used to obtain Innovation and P)
        """
        threshold = self.calculate_background_threshold(x_t)

        # 1. Basic threshold judgment (Corresponding to the Plateau region)
        if x_t < threshold:
            self.prev_x = x_t
            return False, 0.0  # Not exceeding the background, no sampling

        # 2. Gradient Ascent Locking
        # Ensure sampling near peak values (|dx/dt| < epsilon)
        dx_dt = x_t - self.prev_x
        self.prev_x = x_t

        if abs(dx_dt) > self.slope_threshold:
            return False, 0.0  # Still rapidly rising or falling, without sampling

        # 3. Uncertainty-Gated Probabilistic Fusion

        # (a) Calculate innovation rate eta_k
        # eta_k = (Innovation^T * S^-1 * Innovation) / Trace(P)
        # Simplified one-dimensional calculation: S is approximately equal to P (if R is relatively small), here it is approximated as Innovation^2 / P^2
        if kf_instance.trace_P > 1e-9:
            # Simplified one-dimensional implementation of formula (9)
            eta_k = (kf_instance.innovation ** 2) / kf_instance.trace_P
        else:
            eta_k = 0

        # (b) Dynamically adjust reliability weights
        # If eta_k is too large (indicating mutation or model mismatch), reduce the reliability weight
        current_w_R = self.w_R
        if eta_k > 5.0:  # Significance threshold
            current_w_R *= 0.1

            # (c) Calculate the total score J(t)
        # U_Energy: Normalization of Signal Strength (Simplified Example)
        u_energy = min((x_t - threshold) / threshold, 1.0)
        # U_Stability: Stability (the smaller the slope, the more stable it is)
        u_stability = max(1.0 - abs(dx_dt) / self.slope_threshold, 0.0)
        # U_Reliability: Dependent on covariance P (the smaller the P, the more reliable it is)
        u_reliability = max(1.0 - kf_instance.trace_P, 0.0)

        # Weighted sum
        score = self.w_E * u_energy + self.w_S * u_stability + current_w_R * u_reliability

        # Final trigger judgment (assuming a total score threshold of 0.6)
        trigger = score > 0.6
        return trigger, score


# ==========================================
# Simulation
# ==========================================
if __name__ == "__main__":
    # 1. Generate simulated data
    steps = 500
    t = np.linspace(0, 50, steps)
    # Real signal: Feather peak appears between t=20 and t=30
    true_signal = np.zeros_like(t)
    true_signal[200:300] = 5.0 * np.exp(-0.5 * ((t[200:300] - 25) ** 2))

    # Sensor data: including noise and delay
    noise = np.random.normal(0, 0.2, steps)
    # Generate multimodal sensor data for feature fusion
    ch4_data = 0.8 * true_signal + 0.5 * noise  # Methane data
    co2_data = 0.6 * true_signal + 0.4 * noise  # Carbon dioxide data
    chla_data = 0.4 * true_signal + 0.3 * noise  # Chlorophyll a data
    temp_data = 0.2 * true_signal + 0.2 * noise  # Temperature data
    pres_data = 0.3 * true_signal + 0.3 * noise  # Pressure data
    do_data = 0.9 * true_signal + 0.6 * noise   # Dissolved oxygen data
    cond_data = 0.7 * true_signal + 0.5 * noise  # Conductivity data

    # Calculate the conductivity gradient (∇σ(t))
    cond_grad = np.gradient(cond_data)

    # Other sensor data (such as the previously used slow sensor)
    fast_sensor = do_data  # Reference signal (e.g. DO)

    # Slow sensor: lagging by 10 steps
    lag = 10
    slow_sensor = np.roll(true_signal, lag) + noise
    slow_sensor[:lag] = noise[:lag]  # Fix the header data caused by roll

    # 2. Initialization module
    kf_ch4 = AdaptiveKalmanFilter()
    kf_co2 = AdaptiveKalmanFilter()
    kf_chla = AdaptiveKalmanFilter()
    kf_temp = AdaptiveKalmanFilter()
    kf_pres = AdaptiveKalmanFilter()
    kf_do = AdaptiveKalmanFilter()
    kf_cond = AdaptiveKalmanFilter()

    compensator = DynamicCompensator(max_lag=20)
    trigger_sys = RegimeAwareTrigger()

    print(f"{'Time':<5} | {'CH4':<6} | {'CO2':<6} | {'Score':<6} | {'Trigger'}")
    print("-" * 65)

    # 3. Process streaming data point by point
    for i in range(steps):
        # Step 1: Multi sensor Kalman Filter
        filtered_ch4 = kf_ch4.update(ch4_data[i])
        filtered_co2 = kf_co2.update(co2_data[i])
        filtered_chla = kf_chla.update(chla_data[i])
        filtered_temp = kf_temp.update(temp_data[i])
        filtered_pres = kf_pres.update(pres_data[i])
        filtered_do = kf_do.update(do_data[i])
        filtered_cond = kf_cond.update(cond_data[i])

        # Calculate the conductivity gradient
        if i > 0:
            cond_grad_val = filtered_cond - prev_filtered_cond
        else:
            cond_grad_val = 0.0
        prev_filtered_cond = filtered_cond

        # Step 2: Dynamic lag compensation and reconstruction
        recon_val = compensator.process(fast_sensor[i], slow_sensor[i])

        # Step 3: Sampling Decision Using Feature Fusion
        # Create a list of Kalman filters for decision-making purposes
        kf_list = [kf_ch4, kf_co2, kf_chla, kf_temp, kf_pres, kf_do, kf_cond]
        is_trigger, score = trigger_sys.decide_with_features(
            filtered_ch4, filtered_co2, filtered_chla,
            filtered_temp, filtered_pres, filtered_do,
            cond_grad_val, kf_list
        )

        # Only print points near the feather stream for observation
        if 180 < i < 320 and i % 10 == 0:
            # Visual Trigger signal
            trig_str = "SAMPLING!" if is_trigger else ""
            print(
                f"{i:<5} | {filtered_ch4:<6.2f} | {filtered_co2:<6.2f} | {score:<6.2f} | {trig_str}")