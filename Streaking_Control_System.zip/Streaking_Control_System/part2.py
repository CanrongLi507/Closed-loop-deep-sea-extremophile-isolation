import numpy as np
import matplotlib.pyplot as plt


class TopologicalTrajectoryGenerator:
    """
    Section 3.3.1 Perception-Driven ROI Masking and Topological Trajectory Generation
    Function: Based on visual perception of safety boundaries, generate continuous Z-shaped or partition marked trajectories.
    """

    def __init__(self, lambda_safe=0.9):
        self.lambda_safe = lambda_safe  # Safety contraction factor
        self.center = (0, 0)
        self.radius = 0
        self.r_safe = 0

    def set_workspace(self, center, radius):
        """
        Simulate the parameters of the culture dish detected by the Hough circle transformation
        """
        self.center = center
        self.radius = radius
        # Define security boundaries R_safe
        self.r_safe = self.lambda_safe * radius

    def generate_zigzag_trajectory(self, duration=10, dt=0.1, omega=1.0, l_span=40):
        """
        Generate a continuous zigzag line trajectory (Continuous zigzag streaking)
        x(t) = R_safe * cos(omega * t)
        y(t) = S(t) * L_span (S (t) is the sawtooth/triangular wave function)
        """
        t = np.arange(0, duration, dt)
        traj_points = []

        for time in t:
            # Simplified implementation of sinusoidal module
            # Note: In actual robots, sweeping is usually performed within a safe circle
            x = self.r_safe * np.cos(omega * time)

            # Sawtooth function S(t) 
            # Simple triangular wave simulation for lateral scanning
            s_t = 2 * (0.5 - np.abs((time % 1) - 0.5)) - 0.5  # Range [-0.5, 0.5]
            y = s_t * l_span

            # Add center offset
            traj_points.append((self.center[0] + x, self.center[1] + y, 0))  # z=0 nominal

        return np.array(traj_points)

    def generate_sector_pattern(self, num_sectors=3, points_per_sector=50):
        """
        Partition dilution marking (Dilution protocols)
        Generate trajectories for N sectors by rotating the mapping S_local (t)
        """
        trajectories = []

        # Define a local base trajectory (S_local)
        # Draw outward from the center of the circle
        t = np.linspace(0, 1, points_per_sector)
        local_x = t * self.r_safe
        local_y = np.zeros_like(t)

        for j in range(num_sectors):
            theta = (2 * np.pi * j) / num_sectors  # Rotation angle

            # Rotation matrix
            c, s = np.cos(theta), np.sin(theta)
            R = np.array(((c, -s), (s, c)))

            sector_points = []
            for k in range(points_per_sector):
                # Rotation mapping
                p = np.dot(R, np.array([local_x[k], local_y[k]]))
                sector_points.append((self.center[0] + p[0], self.center[1] + p[1], 0))

            trajectories.append(np.array(sector_points))

        return trajectories


class AdmittanceController:
    """
    Section 3.3.2 Concentration-Adaptive Anisotropic Admittance Control
    Function: Adjust target force and damping based on agar concentration to achieve smooth control.
    """

    def __init__(self, agar_concentration=1.0, dt=0.01):
        self.dt = dt
        self.z_cmd = 0.0  # Current command location
        self.z_min = -5.0  # Virtual wall
        self.z_actual = 0.0  # Actual position
        self.v_actual = 0.0  # Actual speed
        self.a_actual = 0.0  # Actual acceleration

        # Complete quality spring damping model parameters
        self.M_d = 0.1  # Virtual Quality (Md)
        self.D_d = 0.0  # Virtual damping (Dd) - will be initialized below
        self.K_d = 5.0  # Virtual stiffness (Kd)

        # Parameter layering setting
        if agar_concentration <= 0.5:
            self.F_set = 0.03  # Mean of [0.02, 0.04]
            self.D_d = 10.0  # Virtual damping
        elif agar_concentration <= 1.0:
            self.F_set = 0.065  # Mean of [0.05, 0.08]
            self.D_d = 15.0
        elif agar_concentration <= 1.5:
            self.F_set = 0.125
            self.D_d = 20.0
        else:  # 2.0%
            self.F_set = 0.20
            self.D_d = 25.0

    def compute_inertia_compensation(self, commanded_acceleration, robot_mass=1.0):
        """
        Calculate inertia compensation term
        Finertia = m * az (From Command Acceleration Profile)
        """
        finertia = robot_mass * commanded_acceleration
        return finertia

    def compute_friction_compensation(self, velocity, static_friction=0.01, viscous_friction_coeff=0.001):
        """
        Calculate Coulomb friction compensation term
        Compensate for the adhesion caused by the viscosity of the agar surface
        """
        # Coulomb friction: static friction+viscous friction
        if abs(velocity) < 1e-6:  # Stationary state
            friction_force = np.sign(velocity) * static_friction if velocity != 0 else 0
        else:  # Motion state
            friction_force = np.sign(velocity) * static_friction + viscous_friction_coeff * velocity
        return friction_force

    def update_full_model(self, z_traj_nominal, f_meas, commanded_accel=None, robot_mass=1.0):
        """
        Execute a complete quality spring damping admittance control update law, including inertia compensation and friction compensation.
        Formula (15): M_d*ë_z + D_d*ė_z + K_d*e_z = F_meas - F_set
        e_z = z_actual - z_ref
        """
        # Calculate position error
        e_z = self.z_actual - z_traj_nominal

        # Calculate external compensation force
        f_inertia = 0.0
        f_friction = 0.0

        if commanded_accel is not None:
            # Inertial compensation: estimating inertial force from command acceleration profile
            f_inertia = self.compute_inertia_compensation(commanded_accel, robot_mass)

        # Friction compensation: compensating for the resistance caused by the viscosity of the agar surface
        f_friction = self.compute_friction_compensation(self.v_actual)

        # Total external compensation force
        f_ext_compensation = f_inertia + f_friction

        # Calculate net force
        net_force = f_meas - self.F_set - f_ext_compensation

        # Solving dynamic equations: M_d*a + D_d*v + K_d*e = net_force
        # a = (net_force - D_d*v - K_d*e) / M_d
        acceleration = (net_force - self.D_d * self.v_actual - self.K_d * e_z) / self.M_d

        # Numerical integration update status
        self.a_actual = acceleration
        self.v_actual += self.a_actual * self.dt
        self.z_actual += self.v_actual * self.dt

        # Update command location
        self.z_cmd = self.z_actual

        # Virtual wall constraint
        if self.z_cmd < self.z_min:
            self.z_cmd = self.z_min
            self.v_actual = 0.0  # After collision, the speed returns to zero
            self.a_actual = 0.0  # Acceleration returns to zero after collision

        return self.z_cmd, self.v_actual, self.a_actual

    def update(self, z_traj_nominal, f_meas):
        """
        Execute admittance control update law.
        First order discrete update ignoring inertia and stiffness terms:
        v_z_cmd[k] = (1/D_d) * (F_meas[k] - F_set)
        z_cmd[k] = z_traj[k] + sum(v_z_cmd * dt)
        """
        # 1. Calculate admittance velocity command
        # Direction check:
        #   Typically, downward pressure is positive.
        #   If F_meas > F_set (excessive force), we need to lift the tool.
        #   Eq. (16) uses (F_meas - F_set), implying v > 0 when F_meas > F_set.
        # Coordinate System Assumption:
        #   Assume Z-axis is positive Upwards (Height), with Z=0 at the surface.
        #   Pressing down decreases Z. 
        #   If force is too high (F_meas > F_set), we need to increase Z (lift up).
        # Conclusion:
        #   v_cmd = (F_meas - F_set) / D_d  ->  v > 0  ->  Z increases (Lift).
        #   The logic is consistent.

        v_z_cmd = (f_meas - self.F_set) / self.D_d

        # 2. Update Position Command
        # Note: `z_traj_nominal` typically represents the estimated surface height (Z_depth) provided by the planning layer.
        # The admittance controller superimposes a correction term onto this nominal value.
        self.z_cmd += v_z_cmd * self.dt

        # 3. Virtual Wall
        # Prevent excessive penetration caused by drift
        if self.z_cmd < self.z_min:
            self.z_cmd = self.z_min

        return self.z_cmd, v_z_cmd


class SafetyManager:
    """
    Section 3.3.3 Finite-State Contact Management and Safety Logic
    Function: Contact detection and energy monitoring.
    """

    def __init__(self, agar_concentration=1.0):
        # Contact threshold setting
        if agar_concentration <= 0.5:
            self.F_high = 0.015
            self.E_max = 0.15  # Rupture limits
        elif agar_concentration <= 1.0:
            self.F_high = 0.03
            self.E_max = 0.4
        elif agar_concentration <= 1.5:
            self.F_high = 0.05
            self.E_max = 0.8
        else:
            self.F_high = 0.08
            self.E_max = 1.2

        self.F_low = self.F_high * 0.5  # Lower bound of hysteresis (assumed value)
        self.contact_state = False
        self.accumulated_energy = 0.0

    def check_contact(self, f_meas):
        """
        Hysteretic Schmitt Trigger
        """
        abs_force = abs(f_meas)
        if abs_force > self.F_high:
            self.contact_state = True
        elif abs_force < self.F_low:
            self.contact_state = False
        return self.contact_state

    def check_safety(self, f_meas, v_z, dt):
        """
        Monitor accumulated work and instantaneous force
        E_accum = Integral |F * v| dt
        """
        # Calculate the absolute value of instantaneous power and integrate it
        power = abs(f_meas * v_z)
        self.accumulated_energy += power * dt

        is_safe = self.accumulated_energy < self.E_max
        return is_safe, self.accumulated_energy


# ==========================================
# Simulation
# ==========================================
if __name__ == "__main__":
    # 1. Environment and parameter settings
    dt = 0.01
    concentration = 1.0  # 1.0% Agar (Medium)

    # Initialization module
    traj_gen = TopologicalTrajectoryGenerator()
    traj_gen.set_workspace(center=(100, 100), radius=45)  # Unit: mm

    controller = AdmittanceController(concentration, dt)
    safety_sys = SafetyManager(concentration)

    # 2. Generated trajectory
    print("Generating Zigzag Trajectory...")
    waypoints = traj_gen.generate_zigzag_trajectory(duration=2.0, dt=dt)

    # 3. Simulate control loop
    print(f"\nStarting Control Loop (Agar Conc: {concentration}%)")
    print(f"{'Time':<6} | {'F_meas':<8} | {'v_cmd':<8} | {'Z_cmd':<8} | {'Contact':<8} | {'Energy':<8}")
    print("-" * 65)

    # Simulated variables
    current_z = 2.0  # Initial height (assuming the surface is z=0)
    sim_force = 0.0
    prev_cmd_z = current_z  # Used to calculate command acceleration

    for i, point in enumerate(waypoints):
        t = i * dt

        # --- Physics Simulation ---
        # Assuming the robot moves downwards and touches the surface (z < 0)
        # Agar appears as a spring: F = K * depth
        agar_stiffness = 5.0  # N/mm
        if current_z < 0:
            sim_force = -current_z * agar_stiffness  # Hooke's Law Simulation
        else:
            sim_force = 0.0

        # --- Algorithm execution ---

        # 1. Safety Check
        # Note: `v_z` refers to either the command from the previous time step 
        #       or the currently measured velocity.
        # Method: Use the rate of change of `controller.z_cmd`.
        is_contact = safety_sys.check_contact(sim_force)

        # 2. Admittance Control Update - Using the full model (with inertia and friction compensation)
        # Calculate the commanded acceleration for inertia compensation
        cmd_acc = 0.0
        if t > dt:  # Calculate acceleration from the second step onwards
            cmd_vel = (controller.z_cmd - prev_cmd_z) / dt
            cmd_acc = (cmd_vel - controller.v_actual) / dt  # Simplified acceleration estimation

        # Update using the complete model
        z_cmd, v_cmd, a_cmd = controller.update_full_model(z_nominal=0.0, f_meas=sim_force,
                                                           commanded_accel=cmd_acc, robot_mass=0.5)

        # Update the command location from the previous step
        prev_cmd_z = controller.z_cmd

        # 3. Energy monitoring
        is_safe, energy = safety_sys.check_safety(sim_force, v_cmd, dt)

        # Update simulation state (Robot response to command)
        # In admittance control, `z_cmd` represents the target position corrected by force.
        # Simulate a "descent" phase: gradually decrease `z_cmd` over time to mimic the approach process.
        if t < 0.5:
            # Approaching stage: forced downward movement
            current_z -= 0.05
        else:
            # Contact Phase: Track the output of the Admittance Controller.
            # Note: The AdmittanceController output typically represents a position correction (relative to z_nominal)
            # or the absolute position directly, depending on the specific implementation.
            # Here, our update method is cumulative (self.z_cmd += v * dt),
            # so it yields the final accumulated position.
            # To drive the simulation, we use this output as the new position state,
            # adding a downward bias to simulate the intention of pressing into the agar.
            current_z = z_cmd - 0.5  # Attempting to press in 0.5mm

        # Print logs
        if i % 20 == 0:
            status = "SAFE" if is_safe else "RUPTURE!"
            contact_str = "YES" if is_contact else "NO"
            print(
                f"{t:<6.2f} | {sim_force:<8.3f} | {v_cmd:<8.3f} | {current_z:<8.3f} | {contact_str:<8} | {energy:<8.4f} {status}")

        if not is_safe:
            print("Emergency Stop Triggered!")
            break